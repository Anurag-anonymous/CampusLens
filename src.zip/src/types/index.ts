export * from './college';
